import React from 'react';
function Profile() {
    return (
<div>
    Welcome Deepika Ray
</div>

    );
}

export default Profile;